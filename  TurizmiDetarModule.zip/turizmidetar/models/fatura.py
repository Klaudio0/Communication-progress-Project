from odoo import fields, models, api
from odoo.exceptions import UserError

class TruizmiFatura(models.Model):
    _name = 'turizmidetar.fatura'
    _description = 'Description'
    _rec_name = 'code'

    code = fields.Char(string='Code', required=True, default='New')
    total = fields.Float(string='Total', compute='_calc_total', store=True)
    date = fields.Date(string='Date', required=True)
    in_out = fields.Boolean(string='In/Out', required=True)
    customer_id = fields.Many2one(comodel_name='turizmidetar.customer', string='Customer', required=True)
    loyalty_card_id = fields.Many2one(
        comodel_name='turizmidetar.loyaltycard',
        string='Loyalty Card',
        compute='_compute_loyalty_card',
        store=True
    )
    points = fields.Float(string='Points', related='customer_id.points', readonly=True)
    employee_id = fields.Many2one(comodel_name='turizmidetar.employeee', string='Employee', required=True)
    state = fields.Selection(string='State', selection=[('draft', 'Draft'), ('done', 'Done'), ('paid', 'Paid')],
                             default='draft')
    pay_method = fields.Selection(string='Pay Method',
                                  selection=[('cash', 'Cash'), ('card', 'Card'), ('point', 'Point')], default='cash')
    invoice_line_ids = fields.One2many(comodel_name='turizmidetar.fatura.line', inverse_name='invoice_id',
                                       string='Invoice Line')

    @api.depends('invoice_line_ids.total')
    def _calc_total(self):
        for invoice in self:
            total_amount = sum(line.total for line in invoice.invoice_line_ids)
            invoice.total = total_amount

    @api.depends('customer_id')
    def _compute_loyalty_card(self):
        for invoice in self:
            loyalty_card = self.env['turizmidetar.loyaltycard'].search([('customer_id', '=', invoice.customer_id.id)],
                                                                       limit=1)
            invoice.loyalty_card_id = loyalty_card

    def action_done(self):
        koef = 1 if self.in_out else -1
        for invoice_line in self.invoice_line_ids:
            invoice_line.product_id.prod_qty += koef * invoice_line.qty
            if invoice_line.product_id.is_sunbed and invoice_line.product_id.sunbed_id:
                invoice_line.product_id.sunbed_id.status = True
        self.state = 'done'

    def action_paid(self):
        if self.pay_method == 'point':
            if self.customer_id.points < self.total:
                raise UserError('Not enough points to pay the invoice.')
            self.customer_id.points -= self.total
        else:
            self.customer_id.points += self.total / 100

        self.state = 'paid'

    @api.model
    def create(self, values):
        if values['in_out']:
            code = self.env['ir.sequence'].next_by_code('in.invoice.cp')
        else:
            code = self.env['ir.sequence'].next_by_code('out.invoice.cp')
        values['code'] = code
        return super(TruizmiFatura, self).create(values)

    def write(self, values):
        return super(TruizmiFatura, self).write(values)

    def unlink(self):
        for invoice in self:
            if invoice.state != 'draft':
                raise UserError('Invoice cannot be deleted unless in draft state')
        return super(TruizmiFatura, self).unlink()

class TurizmiFaturaLines(models.Model):
    _name = 'turizmidetar.fatura.line'

    invoice_id = fields.Many2one(comodel_name='turizmidetar.fatura', string='Invoice', required=True, ondelete='cascade')
    product_id = fields.Many2one(comodel_name='turizmidetar.product', string='Product', required=True)
    sunbed_id = fields.Many2one(comodel_name='turizmidetar.sunbeds', string='Sunbed')
    qty = fields.Float(string='Qty', required=True, default=1)
    price = fields.Float(string='Price', required=True)
    total = fields.Float(string='Total', compute='_calc_total', store=True)
    date = fields.Date(string='Date', related='invoice_id.date')
    discount = fields.Float(string='Discount (%)', compute='_compute_discount', store=True)

    @api.depends('qty', 'price', 'invoice_id.loyalty_card_id.discount')
    def _calc_total(self):
        for line in self:
            discount_percentage = line.invoice_id.loyalty_card_id.discount or 0
            discount_amount = (line.price * discount_percentage / 100) * line.qty
            line.total = (line.price * line.qty) - discount_amount

    @api.depends('invoice_id.loyalty_card_id.discount')
    def _compute_discount(self):
        for line in self:
            line.discount = line.invoice_id.loyalty_card_id.discount or 0
