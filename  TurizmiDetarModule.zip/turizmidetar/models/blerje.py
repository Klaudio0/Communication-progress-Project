from odoo import fields, models


class TurizmiBlerje(models.Model):
    _name = 'turizmidetar.blerje'
    _description = 'Description'

    product_id = fields.Many2one('turizmidetar.product', string='Product')
    quantity = fields.Float(string='Quantity')
    vendor_id = fields.Many2one('turizmidetar.vendor', string='Vendor')
    company_id = fields.Many2one(related='vendor_id.company_id', string='Company')
