from odoo import fields, models


class TurizmiEmployee(models.Model):
    _name = 'turizmidetar.employeee'
    _description = 'Description'
    _rec_name ='employee_name'

    employee_name = fields.Char(string='Employee Name')
    employee_role = fields.Selection(
        string='Role',
        selection=[('manager', 'Manager'),
                   ('cashier', 'Cashier'),
                   ('employee', 'Employee'),
                   ('saler','Saler')],
        required=True)
