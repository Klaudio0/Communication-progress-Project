from odoo import fields, models


class TurizmiCustomer(models.Model):
    _name = 'turizmidetar.customer'
    _description = 'Description'
    _rec_name = 'customer_name'

    customer_name = fields.Char(string="Name", required=True)
    customer_surname = fields.Char(string="Surname", required=True)
    customer_email = fields.Char(string="Email")
    customer_phone = fields.Char(string="Phone")
    customer_nuis = fields.Char(string="NUIS")
    points = fields.Float(string='Points', default=0, readonly=True)



