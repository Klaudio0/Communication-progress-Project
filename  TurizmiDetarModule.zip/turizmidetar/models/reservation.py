from odoo import fields, models, api


class TurizmiReservation(models.Model):
    _name = 'turizmidetar.reservation'
    _description = 'Description'

    start_date = fields.Date(string='Start date', required=False)
    customer_id = fields.Many2one('turizmidetar.customer', string='Customer')
    payment_type = fields.Selection(
        string='Payment type',
        selection=[('Cash', 'Cash'), ('Bank', 'Bank'), ('Card', 'Card')],
        required=True)
    service_id = fields.Many2one(
        comodel_name='turizmidetar.services',
        string='Service',
        required=True)

    status = fields.Selection(string='Status', related='service_id.status', readonly=True)

    @api.model
    def create(self, vals):
        reservation = super(TurizmiReservation, self).create(vals)
        if reservation.service_id:
            reservation.service_id.status = 'reserved'
        return reservation

    def write(self, vals):
        res = super(TurizmiReservation, self).write(vals)
        if self.service_id:
            self.service_id.status = 'reserved'
        return res
