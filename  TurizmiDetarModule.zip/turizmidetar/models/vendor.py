from odoo import fields, models


class TurizmiVendor(models.Model):
    _name = 'turizmidetar.vendor'
    _description = 'Description'
    _rec_name = 'vendor_name'

    vendor_name = fields.Char(string='Vendor Name', required=True)
    company_id = fields.Many2one(string='Company', comodel_name='turizmidetar.company', required=True)


