from odoo import fields, models, api


class TurizmiServices(models.Model):
    _name = 'turizmidetar.services'
    _description = 'Description'
    _rec_name = 'name'

    name = fields.Char(string='Emri i Sherbimit')
    price = fields.Monetary(string='Cmimi i Sherbimit', currency_field='currency_id', )
    status = fields.Selection(
        string='Status',
        selection=[('available', 'Available'),
                   ('reserved', 'Reserved'),
                   ('maintenance', 'Maintenance')],
        required=True)
    code = fields.Char(string='Code')
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.user.company_id.currency_id.id)

    @api.model
    def create(self, vals):
        if 'status' not in vals:
            vals['status'] = 'available'
        return super(TurizmiServices, self).create(vals)

    def make_available(self):
        self.write({'status': 'available'})

    def make_reserved(self):
        self.write({'status': 'reserved'})

    def make_maintenance(self):
        self.write({'status': 'maintenance'})