from odoo import fields, models


class TurizmiCompany(models.Model):
    _name = 'turizmidetar.company'
    _description = 'Description'
    _rec_name = 'company_name'

    company_name = fields.Char(string='Company Name', required=True)

    company_address = fields.Char(string='Company Address', required=True)
    company_city = fields.Char(string='Company City', required=True)
    country_id = fields.Many2one(string='Country', comodel_name='turizmidetar.country', required=True)
