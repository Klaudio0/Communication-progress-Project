from odoo import fields, models, api
from odoo.exceptions import ValidationError


class ProductTurizmi(models.Model):
    _name = 'turizmidetar.product'
    _description = 'Description'
    _rec_name = 'prod_name'

    prod_name = fields.Char(string='Product Name')
    prod_price_cost = fields.Float(string='Product Cost Price')
    prod_sale = fields.Float(string='Sale Price')
    prod_qty = fields.Integer(string='Quantity')
    prod_lines = fields.One2many(
        comodel_name='turizmidetar.product.line',
        inverse_name='prod_id',
        string='Prod line',
        required=True)
    is_sunbed = fields.Boolean(string='Is Sunbed?', default=False)
    sunbed_id = fields.Many2one(comodel_name='turizmidetar.sunbeds', string='Sunbed')

    @api.constrains('prod_qty')
    def _check_quantity(self):
        for product in self:
            if product.prod_qty < 0:
                raise ValidationError('Quantity must be positive')


class TurizmidearProductLine(models.Model):
    _name = 'turizmidetar.product.line'
    _description = 'Description'

    prod_id = fields.Many2one(comodel_name='turizmidetar.product', string='Product')
    prod_color = fields.Char(string='Color')
    prod_size = fields.Integer(string='Size')
