from odoo import fields, models


class TurzimiCountry(models.Model):
    _name = 'turizmidetar.country'
    _description = 'Description'
    _rec_name = 'country_name'
    #perdoret per kur bejme M2O ,,, cila fushe duam ne te shfaqet ne Selection ,,, per mos te dale p.sh turizmideyar, 2,,, por te dali emri i shtetit

    country_name = fields.Char(string='Country')
    country_code = fields.Char(string='ZIP Code')

