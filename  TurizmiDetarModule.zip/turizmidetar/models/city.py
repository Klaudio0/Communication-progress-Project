from odoo import fields, models


class TurizmiCity(models.Model):
    _name = 'turizmidetar.city'
    _description = 'Description'
    _rec_name = 'city_name'

    city_name = fields.Char(string='City')
    country_id = fields.Many2one('turizmidetar.country', string='Country')
    zip_code = fields.Char(string='Code')


