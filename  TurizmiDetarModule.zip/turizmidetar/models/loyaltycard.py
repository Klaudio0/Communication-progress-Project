from odoo import fields, models, api

class LoyaltyCard(models.Model):
    _name = 'turizmidetar.loyaltycard'
    _description = 'Description'
    _rec_name = 'badge'

    customer_id = fields.Many2one(
        comodel_name='turizmidetar.customer',
        string='Client ',
        required=True
    )
    points_client = fields.Float(
        related='customer_id.points',
        string='Points'
    )
    badge = fields.Char(
        string='Badge',
        compute='_compute_badge',
        store=True
    )

    discount = fields.Float(string='Discount', compute='_compute_discount')

    image = fields.Binary(string='Image')

    @api.depends('points_client')
    def _compute_badge(self):
        for record in self:
            if record.points_client > 500:
                record.badge = 'Gold'
            elif record.points_client > 100:
                record.badge = 'Silver'
            else:
                record.badge = 'Bronze'

    @api.depends('badge')
    def _compute_discount(self):
        for record in self:
            if record.badge == 'Silver':
                record.discount = 10
            elif record.badge == 'Gold':
                record.discount = 15
            else:
                record.discount = 5