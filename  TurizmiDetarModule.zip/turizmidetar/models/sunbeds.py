from odoo import fields, models

class TurizmiSunbeds(models.Model):
    _name = 'turizmidetar.sunbeds'
    _description = 'Description'
    _rec_name = 'code'

    code = fields.Char(string='Code')
    status = fields.Boolean(string='Status')
    row_position = fields.Integer(string='Row')
    col_position = fields.Integer(string='Col')